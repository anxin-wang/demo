var host="http://i.e-doctor.cn/api/";
//var host = "http://localhost:3000/api/";
var photo_id='';
function getToken(){
	var hash=location.hash;
	var uid=hash.slice(hash.indexOf("token")).slice(6);
	return uid;
}
function setFooterNavToken(uid){
		$(".nav-home").attr("href","home.html?token="+uid);
		$(".nav-message").attr("href","message.html?token="+uid);
		//$(".nav-profile").attr("href","profile.html?token="+uid);
		//$(".nav-topic").attr("href","topic.html?token="+uid);
		$(".nav-more").attr("href","more.html?token="+uid);
}
// alert dialog dismissed
function alertDismissed() {
    // do something
}
 function preventBehavior(e)
 {
 e.preventDefault();
 };
 document.addEventListener("touchmove", preventBehavior, false);



// Upload files to server
function uploadFile(mediaFile) {
    var options = new FileUploadOptions();
    options.fileName=mediaFile.name;
    var params = new Object();
    params.token = getToken();
    options.params = params;
    
    var ft = new FileTransfer(),
    path = mediaFile.fullPath;
    
    
    ft.upload(path,
              host+"/upload/tweet_photo",
              function(result) {
              
              console.log('Upload success: ' + result.response);
              console.log(result.bytesSent + ' bytes sent');
              //window.localStorage.setItem("mobile", name);
              var resp=eval("("+result.response+")");
              
              photo_id=resp.tweet_photo_id;
              console.log(photo_id);
              },
              function(error) {
              console.log('Error uploading file ' + path + ': ' + error.code);
              },
              options); 
    
}
// Called when capture operation is finished
//
function captureSuccess(mediaFiles) {
    var i, len;
    for (i = 0, len = mediaFiles.length; i < len; i += 1) {
        uploadFile(mediaFiles[i]);
    }       
}

// Called if something bad happens.
// 
function captureError(error) {
    var msg = 'An error occurred during capture: ' + error.code;
    navigator.notification.alert(msg, null, 'Uh oh!');
}

/*********************************************login***********************************************/

  $("#loginPage").live("pagecreate",function(){
                       $("#name").val(window.localStorage.getItem("mobile"));
                       $("#password").val(window.localStorage.getItem("password"));
                       $("#login-btn").click(function(e){
                                             e.preventDefault();
                                             var name=$("#name").val(),
                                             password=$("#password").val();
                                             
                                             if((name =="") || (password =="")){
                                             
                                             navigator.notification.alert('用户名和密码不能为空',alertDismissed,'提示');
                                             
                                             }else{
                                             
                                             $.get(host+"account/verify_credentials",{mobile:name,password:password},function(data){
                                                   
                                                   if((data.error)&&(data.error=="invalid mobile")){
                                                   navigator.notification.alert('用户名和密码不正确',alertDismissed,'提示');
                                                   }else if(data.token){
                                                   window.localStorage.setItem("mobile", name);
                                                   window.localStorage.setItem("password", password);
                                                   window.localStorage.setItem("username", data.username);
                                                   $.mobile.changePage("./home.html?token="+data.token,{ transition: "slideup"} )
                                                   //location.href="./home.html?token="+data.token;
                                                   }
                                                   });
                                             }
                                             })
                       
                       })
/**********************************************************home*************************************************/
  $("#homePage").live("pagebeforeshow",function(){
  	//pagecreate获取不到uid
  	//
                      
                      
                      var uid=getToken();
                      setFooterNavToken(uid);
                      /*
                       * path:
                       statuses/user_timeline
                       parameters:
                       uid: int, default: current_user.id //current_user为当前已登录用户的ID
                       page: int, default:1
                       count: int, default:20
                       max_id:int //获取小于此ID后的微博列表，page和max_id只提供其中一个就可
                       result:
                       同statuses/mentions
                       example:
                       http://t.e-doctor.cn/api/statuses/user_timeline?uid=1&max_id=10
                       */
                      
                      
                      $("h1",this).text(window.localStorage.getItem("username"));
                      $.get(host+"statuses/index",{token:uid,page:1},function(data){
      					if(data.error){
      						$.mobile.changePage("index.html",{ transition: "slidedown"} )
 
      					}else{
      					$("#scroller").weibolist(data.list);
      						
      
      					}
      				})
                      $(".new-weibo-btn").attr("href","newweibo.html?token="+uid);
                      //$(".arrow-btn").attr("href","profile.html?token="+uid);
                      $(".refresh-btn").attr("href","home.html?token="+uid);
            });

/*****************************************************message********************************************/
  $("#mention").live("pagebeforeshow",function(){
	//myScroll = new iScroll('scroller');
	var uid=getToken();
	setFooterNavToken(uid);
	//if(){
    $.get(host+"statuses/mentions",{token:uid,page:1},function(data){
          if(data.error){
          	location.href="index.html";
          }else{
          	$("#scroller").weibolist(data.list);
          }
    })
	
	//}
})
/*****************************************************more***********************************************/	
  
 
	$("#more").live("pagebeforeshow",function(){
     
     myScroll = new iScroll('scroller');
     
     var uid=getToken();
     setFooterNavToken(uid);
     $("#logout-btn").click(function(e){
                           
                            e.preventDefault();
                            $.get(host+"account/end_session",{token:uid},function(data){
                                  if(data.status){
                                  window.localStorage.clear();
                                  location.href="./index.html";
                                  //这里不能换成changePage
                                 }
                                  })
                            });
	})
    


/***********************************************newweibo*****************************************/
  $("#newweibo").live("pagebeforeshow",function(){                      
	$(".send-btn").click(function(){
                         var uid=getToken();
                         console.log(photo_id);
                         var content=$("#content").val();
                         $.post(host+"statuses/update",{
                         	content:content,
                         	tweet_photo_id:photo_id,
                         	token:uid
                        },function(data){
                                if(data.update){
                                	$.mobile.changePage("./home.html?token="+uid,{ transition: "slideup"} )
                                
                                }
                        })
    })
                     
    $("#nav-camera").click(function(){
                           
                                                      
                                                     // Launch device camera application, 
                           // allowing user to capture up to 2 images
                           navigator.device.capture.captureImage(captureSuccess, captureError, {limit: 2});
                          
                           
                           


    })
})
/*************************************************article*****************************************/

  function setContent(obj){
  $("#weibo-user-icon").attr("src",obj.avatar);
  $(".article-title").text(obj.name);
  $(".article-body-words p").text(obj.content);
  $(".article-body-picture img").attr("src",obj.thumb);
  $(".weibo-article-source-middle p").text(obj.parent_tweet.name+":"+obj.parent_tweet.content);
  }
  $("#newweibo").live("pagebeforeshow",function(){
    var obj={
    "geography":null,
    "created_from":"\u7f51\u9875",
    "author_id":2231,
    "content":"\u5434\u519b\u53bb\u75bc\u718f\u5f53VP\u4e86",
    "avatar":"http://localhost:3000/system/images/4711/medium/IMG_0204.jpg",
    "thumb":"http://localhost:3000/system/images/4711/medium/IMG_0204.jpg",
    "name":"\u6881\u9701\u5929",
    "created_at":1313725133,
    "id":122461,
    "parent_tweet":{
    "geography":null,
    "created_from":"\u7f51\u9875","author_id":741,
    "content":"\u597d\u4e66\u5206\u4eab",
    "avatar":"http://localhost:3000/system/images/4921/medium/me.jpg",
    "name":"\u674e\u715c\u6625",
    "created_at":1313722100,
    "id":122451
    }
	};
	$("#entire-article").live("pagecreate",function(){
    
    
    var obj=window.localStorage.getItem("article");
    alert(obj.created_from)
    setContent(obj);
	})
    
    })
  

