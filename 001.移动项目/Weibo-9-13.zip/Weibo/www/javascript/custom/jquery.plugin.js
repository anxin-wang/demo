;(function($) {
	$.fn.weibolist = function(data,options) {
		// Merge passed options with defaults
		var opts = $.extend({}, $.fn.weibolist.defaults, options);
		
		return this.each(function() {
			var container=$(this);
			$.each(data,function(index,item){
				createWeiboItem(item,container,opts);
			})
            var myScroll = new iScroll(this);
			
		});
	};
	function createWeiboItem(obj,container,opts) {
		/*
		 * 				<div class="weibo-list-item">

					<div class="weibo-user-icon"></div>
					<div class="weibo-content">
						<div class="weibo-information">
							<p class="weibo-user-name">
								某医生
							</p>
							<div><img src="resources/images/weibo-picture-icon.png"/>
								<p class="weibo-time">
									8分钟前
								</p>
							</div>
						</div>
						<div class="weibo-short-article" >
							<p>
								信息安全是个得罪人的事情，很多同事会不理解。我想通过讲一些故事，告诉大家，其实这些事并不遥远。今天下午又收到北京同事的客户对我们企业信息安全的审计。如果交得答卷不好，很可能以后失去很多商业机会。这事儿得多沟通，大家都能谅解。毕竟生意减少了，最终损害的还是我们自身的利益。 <a href="">http://edoctor.cc/6f622a</a>
							</p>
						</div>
						<div class="weibo-image"></div>
						<div class="weibo-article-source"></div>
					</div>
				</div>
		 */
		/*
{"geography":null,
"created_from":"\u7f51\u9875",
"author_id":2231,
"content":"\u5434\u519b\u53bb\u75bc\u718f\u5f53VP\u4e86",
"avatar":"http://localhost:3000/system/images/4711/medium/IMG_0204.jpg",
"thumb":"http://localhost:3000/system/images/4711/medium/IMG_0204.jpg",
"name":"\u6881\u9701\u5929",
"created_at":1313725133,
"id":122461,
"parent_tweet":{
	"geography":null,
	"created_from":"\u7f51\u9875","author_id":741,
	"content":"\u597d\u4e66\u5206\u4eab",
	"avatar":"http://localhost:3000/system/images/4921/medium/me.jpg",
	"name":"\u674e\u715c\u6625",
	"created_at":1313722100,
	"id":122451
	}
}
	 	 */
            
		    var html='<div class="weibo-list-item" id="'+obj.id+'"><div class="weibo-user-icon">';
		    if(obj.avatar){
		    	html=html+'<img src="'+obj.avatar+'"/>';
		    }
		    if(obj.name){
		    	html=html+'<p class="weibo-user-name">'+obj.name+'</p>';
		    }
		    
		    html=html+'</div><div class="weibo-content"><div class="weibo-information">';
		    
            html=html+'</div><div class="weibo-short-article" >';
			if(obj.content){
				html=html+'<p>'+obj.content+'</p>';
                
			}
			html=html+'</div>';
			if(obj.thumb){
				html=html+'<div class="weibo-image"><img src="'+obj.thumb+'"/></div>';
			}
			if(obj.parent_tweet){
				html=html+'<div class="weibo-article-source"><div class="weibo-article-source-top"></div><div class="weibo-article-source-middle"><p>'+obj.parent_tweet.name+":"+obj.parent_tweet.content+'</p></div><div class="weibo-article-source-bottom"></div></div>';
			}
			html=html+'</div></div><div class="weibo-list-item-bottom"></div>';
			container.append(html);
            container.find(".weibo-list-item").last().click(function(){
				 window.localStorage.setItem("article", obj);

                 //location.href="./article.html?token="+uid;
				 $.mobile.changePage("./article.html");
            });
		
	}
})(jQuery);